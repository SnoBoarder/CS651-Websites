Brian Tran
btran89@bu.edu
U53262859

Midterm Take-Home Exam

Prerequisites:
- Visual Studio 2015
- ASP.NET Framework should be installed properly, especially ASP.NET Core

Directions:
- Open the "MidtermMVC.sln" with Visual Studio 2015.
- Press "F5" or click the "Green Play Button" to run the project.
- Your preferred browser should open a new tab directing you to the project's URL.
- Enjoy!

Notes:
- Client side logic is in Main.js.

Please let me know if you have any questions.

Here are sample inputs:

1)
LIVITCSWPIYVEWHEVSRIQMXLEYVEOIEWHRXEXIPFEMVEWHKVSTYLXZIXLIKIIXPIJVSZEYPERRGERIMWQLMGLMXQERIWGPSRIHMXQEREKIETXMJTPRGEVEKEITREWHEXXLEXXMZITWAWSQWXSWEXTVEPMRXRSJGSTVRIEYVIEXCVMUIMWERGMIWXMJMGCSMWXSJOMIQXLIVIQIVIXQSVSTWHKPEGARCSXRWIEVSWIIBXVIZMXFSJXLIKEGAEWHEPSWYSWIWIEVXLISXLIVXLIRGEPIRQIVIIBGIIHMWYPFLEVHEWHYPSRRFQMXLEPPXLIECCIEVEWGISJKTVWMRLIHYSPHXLIQIMYLXSJXLIMWRIGXQEROIVFVIZEVAEKPIEWHXEAMWYEPPXLMWYRMWXSGSWRMHIVEXMSWMGSTPHLEVHPFKPEZINTCMXIVJSVLMRSCMWMSWVIRCIGXMWYMX.

2)
lbyeavb ha hpb lagyc at eacb sgbxzqwr. hpb zbm, xi mak vxm pxjb wahqebc, qi ha ihxgh lqhp hpb iqvdyb gkybi xsakh ybhhbg tgbfkbwem, xwc hgm wbl xddgaxepbi awym lpbw hpbib txqy. qw ahpbg lagci, mak dyxm hpb acci ha ihxgh, xwc hpbw xcukih makg ihgxhbrm xi wbbcbc.